package com.zohaib.microservices.Reviews;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;




@RestController
@RequestMapping("/companies/{companyId}")
public class ReviewsController {
  
    ReviewsService service;

    public ReviewsController(ReviewsService service) {
        this.service = service;
    }

    @GetMapping("/reviews")
    public ResponseEntity<List<Review>> getAllReviews(@PathVariable Long companyId) {
        return new ResponseEntity<List<Review>>(service.getReviews(companyId),HttpStatus.OK);    
    }
    
    @PostMapping("/reviews")
    public ResponseEntity<String> createReview(@PathVariable Long companyId,@RequestBody Review entity) {
       boolean isReviewSaved =  service.createReview(companyId,entity);
       if (isReviewSaved) {
        
           return new ResponseEntity<>("Review created successfully",HttpStatus.CREATED);
       }else{
             
        return new ResponseEntity<>("company does not exist",HttpStatus.NOT_FOUND);
           
       }


    }
    
}
