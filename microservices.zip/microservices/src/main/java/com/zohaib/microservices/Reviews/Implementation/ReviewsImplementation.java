package com.zohaib.microservices.Reviews.Implementation;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zohaib.microservices.Company.Company;
import com.zohaib.microservices.Company.CompanyRepository;
import com.zohaib.microservices.Reviews.Review;
import com.zohaib.microservices.Reviews.ReviewsRepository;
import com.zohaib.microservices.Reviews.ReviewsService;

@Service
public class ReviewsImplementation implements ReviewsService {

    private final ReviewsRepository repository;
    private final CompanyRepository companyRepository;

    public ReviewsImplementation(ReviewsRepository repository,CompanyRepository companyRep) {
        this.repository = repository;
        this.companyRepository = companyRep;
    }

    @Override
    public boolean createReview(Long companyId,Review review) {
       
        Company company = companyRepository.findById(companyId).orElse(null);
        
        if (company == null) {
            return false;
        }else{
            review.setCompany(company);
            repository.save(review);
            return true;
        }
        
    }

    @Override
    public List<Review> getReviews(Long companyId) {

        return repository.findByCompanyId(companyId);
    }

    @Override
    public Review getReviewById(Long id) {

        throw new UnsupportedOperationException("Unimplemented method 'getReviewById'");
    }

    @Override
    public boolean deleteReview(Long id) {
       
        throw new UnsupportedOperationException("Unimplemented method 'deleteReview'");
    }

    @Override
    public boolean updateReview(Long id, Review review) {

        throw new UnsupportedOperationException("Unimplemented method 'updateReview'");
    }
}
