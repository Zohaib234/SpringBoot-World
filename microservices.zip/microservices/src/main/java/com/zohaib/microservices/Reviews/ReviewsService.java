package com.zohaib.microservices.Reviews;

import java.util.List;

public interface ReviewsService {

    boolean createReview( Long companyId,Review review);
    List<Review> getReviews(Long companyId);
    Review getReviewById(Long id);
    boolean deleteReview(Long id);
    boolean updateReview(Long id, Review review);
}
